<footer>
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <h4 class="text-info">Siguenos</h4>
        <a href="#" class="text-warning"><i class="fa fa-facebook" aria-hidden="true"></i> &nbsp; Facebook</a><br>
        <a href="#" class="text-warning"><i class="fa fa-twitter" aria-hidden="true"></i> &nbsp; Twitter</a><br>
        <a href="#" class="text-warning"><i class="fa fa-youtube-play" aria-hidden="true"></i> &nbsp; YouTube</a><br>
        <a href="#" class="text-warning"><i class="fa fa-instagram" aria-hidden="true"></i> &nbsp; Instagram</a>
      </div>
      <div class="col-sm-4">
        <h4 class="text-info">Dirección</h4>
        <p class="text-warning"> 
        Pais: El Salvador<br>
        Ciudad: Ciudad<br>
        Telefono: +503 00000000<br>
        E-mail: <a href="#">linuxstore@LStore.com</a>
        </p>
      </div>
      <div class="col-sm-4">
        <h4 class="text-info">Suscribete</h4>
        <p class="text-warning">Suscribete para recibir ofertas y noticias de nuestros productos</p>
        <form action="" method="POST">
          <div class="input-group">
            <input type="email" class="form-control">
            <span class="input-group-btn">
              <button class="btn btn-danger" type="submit">Suscribir</button>
            </span>
          </div>
        </form>
      </div>
    </div>
    <h4 class="text-center" style="color: #FFF;">LinuxStore CopyRight © 2018</h4>
  </div>
</footer>